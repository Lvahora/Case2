﻿using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
    partial class EditProjectForm
    {
        private TextBox txtName;
        private TextBox txtDescription;
        private Button btnSave;

        private void InitializeComponent()
        {
            this.txtName = new TextBox();
            this.txtDescription = new TextBox();
            this.btnSave = new Button();

            // Форма
            this.Text = "Редактирование проекта — FreelanceHub";
            this.Size = new Size(320, 180);
            this.BackColor = Color.FromArgb(30, 30, 30);
            this.StartPosition = FormStartPosition.CenterScreen;

            // txtName
            this.txtName.Location = new Point(100, 20);
            this.txtName.Size = new Size(180, 25);
            this.txtName.BackColor = Color.FromArgb(50, 50, 50);
            this.txtName.ForeColor = Color.White;

            // txtDescription
            this.txtDescription.Location = new Point(100, 60);
            this.txtDescription.Size = new Size(180, 60);
            this.txtDescription.Multiline = true;
            this.txtDescription.BackColor = Color.FromArgb(50, 50, 50);
            this.txtDescription.ForeColor = Color.White;

            // btnSave
            this.btnSave.Location = new Point(100, 130);
            this.btnSave.Size = new Size(180, 35);
            this.btnSave.Text = "Сохранить";
            this.btnSave.FlatStyle = FlatStyle.Flat;
            this.btnSave.BackColor = Color.FromArgb(0, 122, 204);
            this.btnSave.ForeColor = Color.White;

            // Метки
            this.Controls.Add(new Label { Text = "Название:", Location = new Point(20, 20), ForeColor = Color.LightGray });
            this.Controls.Add(new Label { Text = "Описание:", Location = new Point(20, 60), ForeColor = Color.LightGray });

            // Контролы
            this.Controls.Add(txtName);
            this.Controls.Add(txtDescription);
            this.Controls.Add(btnSave);

            // Событие
            this.btnSave.Click += btnSave_Click;
        }
    }
}
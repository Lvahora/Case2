﻿using System;
using System.Data.SQLite;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
    public partial class EditProjectForm : Form
    {
        private int _projectId;

        public EditProjectForm(int projectId)
        {
            _projectId = projectId;
            InitializeComponent();
            LoadProjectData();
        }

        private void LoadProjectData()
        {
            using (var conn = DatabaseManager.GetConnection())
            {
                string sql = "SELECT Name, Description FROM Projects WHERE Id = @projectId";
                using (var cmd = new SQLiteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@projectId", _projectId);
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            txtName.Text = reader["Name"].ToString();
                            txtDescription.Text = reader["Description"].ToString();
                        }
                    }
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string name = txtName.Text.Trim();
            string description = txtDescription.Text.Trim();

            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("Введите название проекта.");
                return;
            }   

            bool success = DatabaseManager.UpdateProject(_projectId, name, description);
            if (success)
            {
                MessageBox.Show("Проект успешно обновлён.");
                this.Close();
            }
            else
            {
                MessageBox.Show("Ошибка при обновлении проекта.");
            }
        }
    }
}
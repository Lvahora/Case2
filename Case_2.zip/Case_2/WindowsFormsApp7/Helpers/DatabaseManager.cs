﻿using System.Data;
using System;
using System.Data.SQLite;
using System.IO;
using WindowsFormsApp7;

public static class DatabaseManager
{
    private static string connectionString = "Data Source=TimeTracker.db;Version=3;Journal Mode=Wal;";

    public static void InitializeDatabase()
    {
        if (!File.Exists("TimeTracker.db")) SQLiteConnection.CreateFile("TimeTracker.db");

        using (var conn = GetConnection())
        {
            string sql = @"
                CREATE TABLE IF NOT EXISTS Users (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Username TEXT NOT NULL UNIQUE,
                    Password TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS Projects (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    UserId INTEGER NOT NULL,
                    Name TEXT NOT NULL,
                    Description TEXT,
                    FOREIGN KEY(UserId) REFERENCES Users(Id)
                );
                CREATE TABLE IF NOT EXISTS Tasks (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ProjectId INTEGER NOT NULL,
                    Name TEXT NOT NULL,
                    Description TEXT,
                    FOREIGN KEY(ProjectId) REFERENCES Projects(Id)
                );
                CREATE TABLE IF NOT EXISTS TimeEntries (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    TaskId INTEGER NOT NULL,
                    StartTime DATETIME NOT NULL,
                    EndTime DATETIME,
                    Duration INTEGER,
                    FOREIGN KEY(TaskId) REFERENCES Tasks(Id)
                );";
            using (var cmd = new SQLiteCommand(sql, conn)) cmd.ExecuteNonQuery();
        }
    }

    public static SQLiteConnection GetConnection()
    {
        var conn = new SQLiteConnection(connectionString);
        conn.Open();
        return conn;
    }

    public static bool RegisterUser(string username, string password)
    {
        using (var conn = GetConnection())
        {
            string sql = "INSERT INTO Users (Username, Password) VALUES (@username, @password)";
            using (var cmd = new SQLiteCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@password", password);
                return cmd.ExecuteNonQuery() > 0;
            }
        }
    }

    public static User LoginUser(string username, string password)
    {
        using (var conn = GetConnection())
        {
            string sql = "SELECT * FROM Users WHERE Username = @username AND Password = @password";
            using (var cmd = new SQLiteCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@password", password);
                using (var reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return new User
                        {
                            Id = Convert.ToInt32(reader["Id"]),
                            Username = reader["Username"].ToString(),
                            Password = reader["Password"].ToString()
                        };
                    }
                    return null;
                }
            }
        }
    }
    public static bool UpdateProject(int projectId, string name, string description)
    {
        using (var conn = GetConnection())
        {
            string sql = "UPDATE Projects SET Name = @name, Description = @description WHERE Id = @projectId";
            using (var cmd = new SQLiteCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@projectId", projectId);
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@description", description ?? "");
                return cmd.ExecuteNonQuery() > 0;
            }
        }
    }

    public static bool AddProject(int userId, string name, string description)
    {
        using (var conn = GetConnection())
        {
            string sql = "INSERT INTO Projects (UserId, Name, Description) VALUES (@userId, @name, @description)";
            using (var cmd = new SQLiteCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@userId", userId);
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@description", description ?? "");
                return cmd.ExecuteNonQuery() > 0;
            }
        }
    }

    public static bool AddTask(int projectId, string name, string description)
    {
        using (var conn = GetConnection())
        {
            string sql = "INSERT INTO Tasks (ProjectId, Name, Description) VALUES (@projectId, @name, @description)";
            using (var cmd = new SQLiteCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@projectId", projectId);
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@description", description ?? "");
                return cmd.ExecuteNonQuery() > 0;
            }
        }
    }
    public static bool DeleteProject(int projectId)
    {
        using (var conn = GetConnection())
        {
            string sql = "DELETE FROM Projects WHERE Id = @projectId";
            using (var cmd = new SQLiteCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@projectId", projectId);
                return cmd.ExecuteNonQuery() > 0;
            }
        }
    }

    public static DataTable GetTimeEntries(DateTime start, DateTime end, int? projectId, int? taskId)
    {
        var table = new DataTable();
        using (var conn = GetConnection())
        {
            string sql = @"SELECT te.*, t.Name AS Task, p.Name AS Project 
                           FROM TimeEntries te
                           JOIN Tasks t ON te.TaskId = t.Id
                           JOIN Projects p ON t.ProjectId = p.Id
                           WHERE te.StartTime BETWEEN @start AND @end";

            using (var cmd = new SQLiteCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@start", start.ToString("yyyy-MM-dd HH:mm:ss"));
                cmd.Parameters.AddWithValue("@end", end.ToString("yyyy-MM-dd HH:mm:ss"));

                using (var reader = cmd.ExecuteReader())
                {
                    table.Load(reader);
                }
            }
        }
        return table;
    }
}
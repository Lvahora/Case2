﻿using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
    partial class MainForm
    {
        private DataGridView dgvProjects;
        private Button btnAddProject;
        private Button btnEditProject;
        private Button btnDeleteProject;
        private Button btnStartTimer;
        private Button btnGenerateReport;

        private void InitializeComponent()
        {
            this.dgvProjects = new DataGridView();
            this.btnAddProject = CreateModernButton("Добавить проект", 620, 30);
            this.btnEditProject = CreateModernButton("Изменить проект", 620, 80);
            this.btnDeleteProject = CreateModernButton("Удалить проект", 620, 130);
            this.btnStartTimer = CreateModernButton("Запустить таймер", 620, 180);
            this.btnGenerateReport = CreateModernButton("Сформировать отчет", 620, 230);

            // dgvProjects
            this.dgvProjects.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProjects.Location = new Point(12, 12);
            this.dgvProjects.Size = new Size(596, 300);
            this.dgvProjects.BackgroundColor = Color.FromArgb(40, 40, 40);
            this.dgvProjects.GridColor = Color.FromArgb(60, 60, 60);
            this.dgvProjects.RowHeadersVisible = false;
            this.dgvProjects.AutoGenerateColumns = false;
            this.dgvProjects.Columns.Add("Name", "Название");
            this.dgvProjects.Columns.Add("Description", "Описание");

            // Форма
            this.Text = "Главная — FreelanceHub";
            this.Size = new Size(822, 582);
            this.BackColor = Color.FromArgb(30, 30, 30);
            this.StartPosition = FormStartPosition.CenterScreen;

            // Добавление контролов
            this.Controls.Add(dgvProjects);
            this.Controls.Add(btnAddProject);
            this.Controls.Add(btnEditProject);
            this.Controls.Add(btnDeleteProject);
            this.Controls.Add(btnStartTimer);
            this.Controls.Add(btnGenerateReport);

            // События
            this.btnAddProject.Click += btnAddProject_Click;
        }

        private Button CreateModernButton(string text, int x, int y)
        {
            return new Button
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(180, 35),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(0, 122, 204),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                FlatAppearance = { MouseOverBackColor = Color.FromArgb(0, 150, 220), BorderSize = 0 }
            };
        }
    }
}
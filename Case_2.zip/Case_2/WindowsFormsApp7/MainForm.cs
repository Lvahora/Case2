﻿using System.Data.SQLite;
using System;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();

            dgvProjects.Columns.Add("Id", "ID");
            dgvProjects.Columns.Add("Name", "Название");
            dgvProjects.Columns.Add("Description", "Описание");

            btnEditProject.Click += btnEditProject_Click;
            btnDeleteProject.Click += btnDeleteProject_Click;
            btnStartTimer.Click += btnStartTimer_Click;
            btnGenerateReport.Click += btnGenerateReport_Click;

            LoadProjects();
        }

        private void LoadProjects()
        {
            using (var conn = DatabaseManager.GetConnection())
            {
                string sql = "SELECT * FROM Projects WHERE UserId = @userId";
                using (var cmd = new SQLiteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@userId", CurrentUser.Id);
                    using (var reader = cmd.ExecuteReader())
                    {
                        dgvProjects.Rows.Clear(); 
                        while (reader.Read())
                        {
                            dgvProjects.Rows.Add(
                                reader["Id"],
                                reader["Name"],
                                reader["Description"]
                            );
                        }
                    }
                }
            }
        }

        private void btnAddProject_Click(object sender, EventArgs e)
        {
            new ProjectForm(CurrentUser.Id).ShowDialog();
            LoadProjects();
        }

        private void btnEditProject_Click(object sender, EventArgs e)
        {
            if (dgvProjects.SelectedRows.Count > 0)
            {
                var selectedRow = dgvProjects.SelectedRows[0];
                int projectId = Convert.ToInt32(selectedRow.Cells["Id"].Value);
                new EditProjectForm(projectId).ShowDialog();
                LoadProjects();
            }
            else
            {
                MessageBox.Show("Выберите проект для редактирования.");
            }
        }


        private void btnDeleteProject_Click(object sender, EventArgs e)
        {
            if (dgvProjects.SelectedRows.Count > 0)
            {
                var selectedRow = dgvProjects.SelectedRows[0];
                int projectId = Convert.ToInt32(selectedRow.Cells["Id"].Value);

                if (MessageBox.Show("Вы уверены, что хотите удалить этот проект?", "Подтверждение", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    bool success = DatabaseManager.DeleteProject(projectId);
                    if (success)
                    {
                        MessageBox.Show("Проект успешно удален.");
                        LoadProjects();
                    }
                    else
                    {
                        MessageBox.Show("Ошибка при удалении проекта.");
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите проект для удаления.");
            }
        }
        private void btnStartTimer_Click(object sender, EventArgs e)
        {
            if (dgvProjects.SelectedRows.Count > 0)
            {
                var selectedRow = dgvProjects.SelectedRows[0];
                int projectId = Convert.ToInt32(selectedRow.Cells["Id"].Value);

                var taskForm = new TaskForm(projectId);
                taskForm.ShowDialog();

                if (taskForm.SelectedTaskId.HasValue)
                {
                    new TimerForm(taskForm.SelectedTaskId.Value).ShowDialog();
                }
            }
            else
            {
                MessageBox.Show("Выберите проект для запуска таймера.");
            }
        }
        private void btnGenerateReport_Click(object sender, EventArgs e)
        {
            new ReportForm().ShowDialog();
        }
    }
}
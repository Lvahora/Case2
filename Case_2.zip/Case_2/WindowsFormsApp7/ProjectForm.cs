﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
    public partial class ProjectForm : Form
    {
        private int _userId;

        public ProjectForm(int userId)
        {
            _userId = userId;
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string name = txtName.Text.Trim();
            string description = txtDescription.Text.Trim();

            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("Введите название проекта.");
                return;
            }

            bool success = DatabaseManager.AddProject(_userId, name, description);
            if (success)
            {
                MessageBox.Show("Проект сохранён.");
                this.Close();
            }
            else
            {
                MessageBox.Show("Ошибка при добавлении проекта.");
            }
        }
    }
}
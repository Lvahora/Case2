﻿using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
    partial class RegisterForm
    {
        private TextBox txtUsername;
        private TextBox txtPassword;
        private Button btnSave;

        private void InitializeComponent()
        {
            this.txtUsername = new TextBox();
            this.txtPassword = new TextBox();
            this.btnSave = new Button();

            // Форма
            this.Text = "Регистрация — FreelanceHub";
            this.Size = new Size(320, 200);
            this.BackColor = Color.FromArgb(30, 30, 30);
            this.StartPosition = FormStartPosition.CenterScreen;

            // txtUsername
            this.txtUsername.Location = new Point(100, 20);
            this.txtUsername.Size = new Size(180, 25);
            this.txtUsername.BackColor = Color.FromArgb(50, 50, 50);
            this.txtUsername.ForeColor = Color.White;
            this.txtUsername.BorderStyle = BorderStyle.FixedSingle;

            // txtPassword
            this.txtPassword.Location = new Point(100, 60);
            this.txtPassword.Size = new Size(180, 25);
            this.txtPassword.BackColor = Color.FromArgb(50, 50, 50);
            this.txtPassword.ForeColor = Color.White;
            this.txtPassword.UseSystemPasswordChar = true;
            this.txtPassword.BorderStyle = BorderStyle.FixedSingle;

            // btnSave
            this.btnSave.Location = new Point(100, 100);
            this.btnSave.Size = new Size(180, 35);
            this.btnSave.Text = "Сохранить";
            this.btnSave.FlatStyle = FlatStyle.Flat;
            this.btnSave.BackColor = Color.FromArgb(0, 122, 204);
            this.btnSave.ForeColor = Color.White;
            this.btnSave.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.btnSave.FlatAppearance.BorderSize = 0;
            this.btnSave.FlatAppearance.MouseOverBackColor = Color.FromArgb(0, 150, 220);

            // Метки
            this.Controls.Add(new Label { Text = "Логин:", Location = new Point(20, 20), ForeColor = Color.LightGray, AutoSize = true });
            this.Controls.Add(new Label { Text = "Пароль:", Location = new Point(20, 60), ForeColor = Color.LightGray, AutoSize = true });

            // Контролы
            this.Controls.Add(this.txtUsername);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.btnSave);

            // Событие
            this.btnSave.Click += btnSave_Click;
        }
    }
}
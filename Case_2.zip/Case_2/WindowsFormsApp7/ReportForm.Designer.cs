﻿using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
    partial class ReportForm
    {
        private DateTimePicker dtpStartDate;
        private DateTimePicker dtpEndDate;
        private ComboBox cmbProject;
        private ComboBox cmbTask;
        private Button btnGenerate;
        private Button btnExportPdf;
        private Button btnExportCsv;
        private DataGridView dgvReport;

        private void InitializeComponent()
        {
            this.dtpStartDate = new DateTimePicker();
            this.dtpEndDate = new DateTimePicker();
            this.cmbProject = new ComboBox();
            this.cmbTask = new ComboBox();
            this.btnGenerate = new Button();
            this.btnExportPdf = new Button();
            this.btnExportCsv = new Button();
            this.dgvReport = new DataGridView();

            // Настройка формы
            this.Text = "Отчет — FreelanceHub";
            this.Size = new Size(822, 582);
            this.BackColor = Color.FromArgb(30, 30, 30);
            this.StartPosition = FormStartPosition.CenterScreen;

            // dtpStartDate
            this.dtpStartDate.Format = DateTimePickerFormat.Short;
            this.dtpStartDate.Location = new Point(100, 20);

            // dtpEndDate
            this.dtpEndDate.Format = DateTimePickerFormat.Short;
            this.dtpEndDate.Location = new Point(100, 50);

            // cmbProject
            this.cmbProject.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cmbProject.Location = new Point(100, 80);
            this.cmbProject.Size = new Size(180, 25);
            this.cmbProject.BackColor = Color.FromArgb(50, 50, 50);
            this.cmbProject.ForeColor = Color.White;

            // cmbTask
            this.cmbTask.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cmbTask.Location = new Point(100, 110);
            this.cmbTask.Size = new Size(180, 25);
            this.cmbTask.BackColor = Color.FromArgb(50, 50, 50);
            this.cmbTask.ForeColor = Color.White;

            // Кнопки
            this.btnGenerate = CreateModernButton("Сформировать", 620, 30);
            this.btnExportPdf = CreateModernButton("Экспорт PDF", 620, 80);
            this.btnExportCsv = CreateModernButton("Экспорт CSV", 620, 130);

            // dgvReport
            this.dgvReport.Location = new Point(12, 140);
            this.dgvReport.Size = new Size(596, 300);
            this.dgvReport.AutoGenerateColumns = true;
            this.dgvReport.BackgroundColor = Color.FromArgb(40, 40, 40);
            this.dgvReport.GridColor = Color.FromArgb(60, 60, 60);
            this.dgvReport.RowHeadersVisible = false;

            // Метки
            this.Controls.Add(new Label { Text = "С даты:", Location = new Point(20, 20), ForeColor = Color.LightGray, AutoSize = true });
            this.Controls.Add(new Label { Text = "По дату:", Location = new Point(20, 50), ForeColor = Color.LightGray, AutoSize = true });
            this.Controls.Add(new Label { Text = "Проект:", Location = new Point(20, 80), ForeColor = Color.LightGray, AutoSize = true });
            this.Controls.Add(new Label { Text = "Задача:", Location = new Point(20, 110), ForeColor = Color.LightGray, AutoSize = true });

            // Добавление контролов
            this.Controls.Add(this.dtpStartDate);
            this.Controls.Add(this.dtpEndDate);
            this.Controls.Add(this.cmbProject);
            this.Controls.Add(this.cmbTask);
            this.Controls.Add(this.btnGenerate);
            this.Controls.Add(this.btnExportPdf);
            this.Controls.Add(this.btnExportCsv);
            this.Controls.Add(this.dgvReport);

            // События
            this.btnGenerate.Click += btnGenerate_Click;
            this.btnExportPdf.Click += btnExportPdf_Click;
            this.btnExportCsv.Click += btnExportCsv_Click;
        }

        private Button CreateModernButton(string text, int x, int y)
        {
            return new Button
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(180, 35),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(0, 122, 204),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                FlatAppearance = { MouseOverBackColor = Color.FromArgb(0, 150, 220), BorderSize = 0 }
            };
        }
    }
}
﻿using System;
using System.Data;
using System.Windows.Forms;
using WindowsFormsApp7.Reports;

namespace WindowsFormsApp7
{
    public partial class ReportForm : Form
    {
        public ReportForm()
        {
            InitializeComponent();
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            DateTime startDate = dtpStartDate.Value.Date;
            DateTime endDate = dtpEndDate.Value.Date.AddDays(1).AddSeconds(-1); // Включительно

            DataTable data = DatabaseManager.GetTimeEntries(startDate, endDate, null, null);
            dgvReport.DataSource = data;
        }

        private void btnExportPdf_Click(object sender, EventArgs e)
        {
            using (var dialog = new SaveFileDialog { Filter = "PDF Files (*.pdf)|*.pdf" })
            {
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    ReportExporter.ExportToPdf(dgvReport.DataSource as DataTable, dialog.FileName);
                    MessageBox.Show("Отчет экспортирован в PDF.");
                }
            }
        }

        private void btnExportCsv_Click(object sender, EventArgs e)
        {
            using (var dialog = new SaveFileDialog { Filter = "CSV Files (*.csv)|*.csv" })
            {
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    ReportExporter.ExportToCsv(dgvReport.DataSource as DataTable, dialog.FileName);
                    MessageBox.Show("Отчет экспортирован в CSV.");
                }
            }
        }
    }
}
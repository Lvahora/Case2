﻿using System.Data;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace WindowsFormsApp7.Reports
{
    public static class ReportExporter
    {
        public static void ExportToCsv(DataTable data, string filePath)
        {
            using (var writer = new StreamWriter(filePath))
            {
                writer.WriteLine(string.Join(",", data.Columns.Cast<DataColumn>().Select(c => c.ColumnName)));
                foreach (DataRow row in data.Rows)
                {
                    writer.WriteLine(string.Join(",", row.ItemArray.Select(x => x.ToString())));
                }
            }
        }

        public static void ExportToPdf(DataTable data, string filePath)
        {
            MessageBox.Show("Функция экспорта в PDF пока не реализована."); 
        }
    }
}
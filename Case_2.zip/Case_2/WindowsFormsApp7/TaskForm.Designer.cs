﻿using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
    partial class TaskForm
    {
        private void InitializeComponent()
        {
            this.cmbTasks = new ComboBox();
            this.txtName = new TextBox();
            this.txtDescription = new TextBox();
            this.btnSave = new Button();
            this.btnSelect = new Button();

            // Настройки формы
            this.Text = "Добавление задачи — FreelanceHub";
            this.Size = new Size(400, 300);
            this.BackColor = Color.FromArgb(30, 30, 30);
            this.StartPosition = FormStartPosition.CenterScreen;

            // cmbTasks
            this.cmbTasks.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cmbTasks.Location = new Point(50, 30);
            this.cmbTasks.Size = new Size(250, 25);
            this.cmbTasks.BackColor = Color.FromArgb(50, 50, 50);
            this.cmbTasks.ForeColor = Color.White;

            // btnSelect
            this.btnSelect.Location = new Point(310, 28);
            this.btnSelect.Size = new Size(75, 25);
            this.btnSelect.Text = "Выбрать";
            this.btnSelect.FlatStyle = FlatStyle.Flat;
            this.btnSelect.BackColor = Color.FromArgb(0, 122, 204);
            this.btnSelect.ForeColor = Color.White;
            this.btnSelect.FlatAppearance.BorderSize = 0;

            // txtName
            this.txtName.Location = new Point(50, 70);
            this.txtName.Size = new Size(250, 25);
            this.txtName.BackColor = Color.FromArgb(50, 50, 50);
            this.txtName.ForeColor = Color.White;

            // txtDescription
            this.txtDescription.Location = new Point(50, 110);
            this.txtDescription.Size = new Size(250, 60);
            this.txtDescription.Multiline = true;
            this.txtDescription.BackColor = Color.FromArgb(50, 50, 50);
            this.txtDescription.ForeColor = Color.White;

            // btnSave
            this.btnSave.Location = new Point(50, 180);
            this.btnSave.Size = new Size(180, 35);
            this.btnSave.Text = "Сохранить";
            this.btnSave.FlatStyle = FlatStyle.Flat;
            this.btnSave.BackColor = Color.FromArgb(0, 122, 204);
            this.btnSave.ForeColor = Color.White;
            this.btnSave.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.btnSave.FlatAppearance.BorderSize = 0;

            // Добавление контролов
            this.Controls.Add(this.cmbTasks);
            this.Controls.Add(this.btnSelect);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.txtDescription);
            this.Controls.Add(this.btnSave);

            // События
            this.btnSave.Click += btnSave_Click;
            this.btnSelect.Click += btnSelect_Click;
        }
    }
}
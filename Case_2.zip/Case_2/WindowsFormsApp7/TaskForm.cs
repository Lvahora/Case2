﻿using System;
using System.Data.SQLite;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
    public partial class TaskForm : Form
    {
        private int _projectId;
        public int? SelectedTaskId { get; private set; }

        public TaskForm(int projectId) : this(projectId, null) { }

        public TaskForm(int projectId, int? selectedTaskId)
        {
            _projectId = projectId;
            InitializeComponent();
            LoadTasks(selectedTaskId);
        }

        private void LoadTasks(int? selectedTaskId)
        {
            using (var conn = DatabaseManager.GetConnection())
            {
                string sql = "SELECT Id, Name FROM Tasks WHERE ProjectId = @projectId";
                using (var cmd = new SQLiteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@projectId", _projectId);
                    using (var reader = cmd.ExecuteReader())
                    {
                        cmbTasks.Items.Clear();
                        while (reader.Read())
                        {
                            var task = new
                            {
                                Id = Convert.ToInt32(reader["Id"]),
                                Name = reader["Name"].ToString()
                            };
                            cmbTasks.Items.Add(task);
                            if (selectedTaskId.HasValue && task.Id == selectedTaskId.Value)
                            {
                                cmbTasks.SelectedItem = task;
                            }
                        }
                    }
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string name = txtName.Text.Trim();
            string description = txtDescription.Text.Trim();
            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("Введите название задачи.");
                return;
            }
            bool success = DatabaseManager.AddTask(_projectId, name, description);
            if (success)
            {
                MessageBox.Show("Задача добавлена.");
                LoadTasks(null);
            }
            else
            {
                MessageBox.Show("Ошибка при добавлении задачи.");
            }
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            if (cmbTasks.SelectedItem != null)
            {
                var task = (dynamic)cmbTasks.SelectedItem;
                SelectedTaskId = task.Id;
                this.Close();
            }
            else
            {
                MessageBox.Show("Выберите задачу.");
            }
        }

        #region Controls
        private ComboBox cmbTasks;
        private TextBox txtName;
        private TextBox txtDescription;
        private Button btnSave;
        private Button btnSelect;
        #endregion
    }
}
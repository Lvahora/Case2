﻿using System;
using System.Data.SQLite;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
    public partial class TimerForm : Form
    {
        private int _taskId;
        private DateTime? _startTime;
        private Timer _timer;

        public TimerForm(int taskId)
        {
            _taskId = taskId;
            InitializeComponent();
            _timer = new Timer { Interval = 1000 };
            _timer.Tick += Timer_Tick;
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            lblDuration.Text = CalculateDuration().ToString(@"hh\:mm\:ss");
        }

        private TimeSpan CalculateDuration()
        {
            return _startTime.HasValue ? DateTime.Now - _startTime.Value : TimeSpan.Zero;
        }

        private void btnStartStop_Click(object sender, EventArgs e)
        {
            if (_startTime == null)
            {
                _startTime = DateTime.Now;
                _timer.Start();
                btnStartStop.Text = "Стоп";
            }
            else
            {
                _timer.Stop();
                SaveTimeEntry();
                _startTime = null;
                btnStartStop.Text = "Старт";
            }
        }

        private void SaveTimeEntry()
        {
            using (var conn = DatabaseManager.GetConnection())
            {
                string sql = "INSERT INTO TimeEntries (TaskId, StartTime, EndTime, Duration) VALUES (@taskId, @startTime, @endTime, @duration)";
                using (var cmd = new SQLiteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@taskId", _taskId);
                    cmd.Parameters.AddWithValue("@startTime", _startTime);
                    cmd.Parameters.AddWithValue("@endTime", DateTime.Now);
                    cmd.Parameters.AddWithValue("@duration", CalculateDuration().TotalSeconds);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        #region Designer Components
        private Label lblDuration;
        private Button btnStartStop;
        #endregion

        private void btnSave_Click(object sender, EventArgs e)
        {

        }

        private void btnSelect_Click(object sender, EventArgs e)
        {

        }
    }
}
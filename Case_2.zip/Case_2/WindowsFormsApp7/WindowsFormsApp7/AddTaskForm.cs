﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace WindowsFormsApp7
{
    public partial class AddTaskForm : Form
    {
        private int _projectId;

        public AddTaskForm(int projectId)
        {
            _projectId = projectId;
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string name = txtName.Text.Trim();
            string description = txtDescription.Text.Trim();
            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("Введите название задачи.");
                return;
            }

            bool success = DatabaseManager.AddTask(_projectId, name, description);
            if (success)
            {
                MessageBox.Show("Задача добавлена.");
                this.Close();
            }
            else
            {
                MessageBox.Show("Ошибка при добавлении задачи.");
            }
        }
    }
}

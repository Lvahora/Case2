﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace WindowsFormsApp7
{
    public partial class EditTaskForm : Form
    {
        private int _taskId;

        public EditTaskForm(int taskId)
        {
            _taskId = taskId;
            InitializeComponent();
            LoadTaskData();
        }

        private void LoadTaskData()
        {
            using (var conn = DatabaseManager.GetConnection())
            {
                string sql = "SELECT Name, Description FROM Tasks WHERE Id = @taskId";
                using (var cmd = new SQLiteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@taskId", _taskId);
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            txtName.Text = reader["Name"].ToString();
                            txtDescription.Text = reader["Description"].ToString();
                        }
                    }
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string name = txtName.Text.Trim();
            string description = txtDescription.Text.Trim();
            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("Введите название задачи.");
                return;
            }

            bool success = DatabaseManager.UpdateTask(_taskId, name, description);
            if (success)
            {
                MessageBox.Show("Задача обновлена.");
                this.Close();
            }
            else
            {
                MessageBox.Show("Ошибка при обновлении задачи.");
            }
        }
    }
}

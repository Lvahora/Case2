﻿using System.Data.SQLite;
using System.Data;
using System;
using WindowsFormsApp7;

public static class DatabaseManager
{
    private static string connectionString = "Data Source=TimeTracker.db;Version=3;Journal Mode=Wal;";

    public static void InitializeDatabase()
    {
        if (!File.Exists("TimeTracker.db")) SQLiteConnection.CreateFile("TimeTracker.db");
        using (var conn = GetConnection())
        {
            string sql = @"
                CREATE TABLE IF NOT EXISTS Users (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Username TEXT NOT NULL UNIQUE,
                    Password TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS Projects (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    UserId INTEGER NOT NULL,
                    Name TEXT NOT NULL,
                    Description TEXT,
                    FOREIGN KEY(UserId) REFERENCES Users(Id)
                );
                CREATE TABLE IF NOT EXISTS Tasks (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ProjectId INTEGER NOT NULL,
                    Name TEXT NOT NULL,
                    Description TEXT,
                    FOREIGN KEY(ProjectId) REFERENCES Projects(Id)
                );
                CREATE TABLE IF NOT EXISTS TimeEntries (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    TaskId INTEGER NOT NULL,
                    StartTime DATETIME NOT NULL,
                    EndTime DATETIME,
                    Duration INTEGER,
                    FOREIGN KEY(TaskId) REFERENCES Tasks(Id)
                );";
            using (var cmd = new SQLiteCommand(sql, conn)) cmd.ExecuteNonQuery();
        }
    }

    public static SQLiteConnection GetConnection()
    {
        var conn = new SQLiteConnection(connectionString);
        conn.Open();
        return conn;
    }

    // Регистрация и авторизация
    public static bool RegisterUser(string username, string password)
    {
        try
        {
            using (var conn = GetConnection())
            {
                string sql = "INSERT INTO Users (Username, Password) VALUES (@username, @password)";
                using (var cmd = new SQLiteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@password", password);
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }
        catch
        {
            return false;
        }
    }

    public static User LoginUser(string username, string password)
    {
        try
        {
            using (var conn = GetConnection())
            {
                string sql = "SELECT * FROM Users WHERE Username = @username AND Password = @password";
                using (var cmd = new SQLiteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@password", password);
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new User
                            {
                                Id = Convert.ToInt32(reader["Id"]),
                                Username = reader["Username"].ToString(),
                                Password = reader["Password"].ToString()
                            };
                        }
                        return null;
                    }
                }
            }
        }
        catch
        {
            return null;
        }
    }

    // Управление проектами
    public static bool AddProject(int userId, string name, string description)
    {
        try
        {
            using (var conn = GetConnection())
            {
                string sql = "INSERT INTO Projects (UserId, Name, Description) VALUES (@userId, @name, @description)";
                using (var cmd = new SQLiteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@userId", userId);
                    cmd.Parameters.AddWithValue("@name", name);
                    cmd.Parameters.AddWithValue("@description", description ?? "");
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }
        catch
        {
            return false;
        }
    }

    public static bool UpdateProject(int projectId, string name, string description)
    {
        try
        {
            using (var conn = GetConnection())
            {
                string sql = "UPDATE Projects SET Name = @name, Description = @description WHERE Id = @projectId";
                using (var cmd = new SQLiteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@projectId", projectId);
                    cmd.Parameters.AddWithValue("@name", name);
                    cmd.Parameters.AddWithValue("@description", description ?? "");
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }
        catch
        {
            return false;
        }
    }

    public static bool DeleteProject(int projectId)
    {
        try
        {
            using (var conn = GetConnection())
            {
                string sql = "DELETE FROM Projects WHERE Id = @projectId";
                using (var cmd = new SQLiteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@projectId", projectId);
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }
        catch
        {
            return false;
        }
    }

    public static DataTable GetProjectsForUser(int userId)
    {
        var table = new DataTable();
        using (var conn = GetConnection())
        {
            string sql = "SELECT * FROM Projects WHERE UserId = @userId";
            using (var cmd = new SQLiteCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@userId", userId);
                using (var reader = cmd.ExecuteReader())
                    table.Load(reader);
            }
        }
        return table;
    }

    // Управление задачами
    public static bool AddTask(int projectId, string name, string description)
    {
        try
        {
            using (var conn = GetConnection())
            {
                string sql = "INSERT INTO Tasks (ProjectId, Name, Description) VALUES (@projectId, @name, @description)";
                using (var cmd = new SQLiteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@projectId", projectId);
                    cmd.Parameters.AddWithValue("@name", name);
                    cmd.Parameters.AddWithValue("@description", description ?? "");
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }
        catch
        {
            return false;
        }
    }

    public static bool UpdateTask(int taskId, string name, string description)
    {
        try
        {
            using (var conn = GetConnection())
            {
                string sql = "UPDATE Tasks SET Name = @name, Description = @description WHERE Id = @taskId";
                using (var cmd = new SQLiteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@taskId", taskId);
                    cmd.Parameters.AddWithValue("@name", name);
                    cmd.Parameters.AddWithValue("@description", description ?? "");
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }
        catch
        {
            return false;
        }
    }

    public static bool DeleteTask(int taskId)
    {
        try
        {
            using (var conn = GetConnection())
            {
                string sql = "DELETE FROM Tasks WHERE Id = @taskId";
                using (var cmd = new SQLiteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@taskId", taskId);
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }
        catch
        {
            return false;
        }
    }

    public static DataTable GetTasksForProject(int projectId)
    {
        var table = new DataTable();
        using (var conn = GetConnection())
        {
            string sql = "SELECT * FROM Tasks WHERE ProjectId = @projectId";
            using (var cmd = new SQLiteCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@projectId", projectId);
                using (var reader = cmd.ExecuteReader())
                    table.Load(reader);
            }
        }
        return table;
    }

    // Таймер и отчеты
    public static bool AddTimeEntry(int taskId, DateTime startTime, DateTime? endTime, int duration)
    {
        try
        {
            using (var conn = GetConnection())
            {
                string sql = "INSERT INTO TimeEntries (TaskId, StartTime, EndTime, Duration) VALUES (@taskId, @startTime, @endTime, @duration)";
                using (var cmd = new SQLiteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@taskId", taskId);
                    cmd.Parameters.AddWithValue("@startTime", startTime);
                    cmd.Parameters.AddWithValue("@endTime", endTime ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@duration", duration);
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }
        catch
        {
            return false;
        }
    }

    public static bool UpdateTimeEntry(int id, DateTime? endTime, int duration)
    {
        try
        {
            using (var conn = GetConnection())
            {
                string sql = "UPDATE TimeEntries SET EndTime = @endTime, Duration = @duration WHERE Id = @id";
                using (var cmd = new SQLiteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.Parameters.AddWithValue("@endTime", endTime ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@duration", duration);
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }
        catch
        {
            return false;
        }
    }

    public static DataTable GetTimeEntries(DateTime start, DateTime end, int? projectId, int? taskId)
    {
        var table = new DataTable();
        using (var conn = GetConnection())
        {
            string sql = @"SELECT te.*, t.Name AS Task, p.Name AS Project 
                          FROM TimeEntries te
                          JOIN Tasks t ON te.TaskId = t.Id
                          JOIN Projects p ON t.ProjectId = p.Id
                          WHERE te.StartTime BETWEEN @start AND @end";

            if (projectId.HasValue)
                sql += " AND p.Id = @projectId";
            if (taskId.HasValue)
                sql += " AND t.Id = @taskId";

            using (var cmd = new SQLiteCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@start", start.ToString("yyyy-MM-dd HH:mm:ss"));
                cmd.Parameters.AddWithValue("@end", end.ToString("yyyy-MM-dd HH:mm:ss"));
                if (projectId.HasValue)
                    cmd.Parameters.AddWithValue("@projectId", projectId.Value);
                if (taskId.HasValue)
                    cmd.Parameters.AddWithValue("@taskId", taskId.Value);

                using (var reader = cmd.ExecuteReader())
                    table.Load(reader);
            }
        }
        return table;
    }
}
﻿using System.Data;
using System.Drawing.Printing;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Xml.Linq;
using iText.Kernel.Font;
using iText.Kernel.Pdf;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Properties;
using iText.Kernel.Colors;

namespace WindowsFormsApp7.Reports
{
    public static class ReportExporter
    {
        public static void ExportToCsv(DataTable data, string filePath)
        {
            using (var writer = new StreamWriter(filePath))
            {
                writer.WriteLine(string.Join(",", data.Columns.Cast<DataColumn>().Select(c => c.ColumnName)));
                foreach (DataRow row in data.Rows)
                {
                    writer.WriteLine(string.Join(",", row.ItemArray.Select(x => x.ToString())));
                }
            }
        }

        public static void ExportToPdf(DataTable data, string filePath)
        {
            using (FileStream stream = new FileStream(filePath, FileMode.Create))
            {
                var writer = new PdfWriter(stream);
                var pdf = new PdfDocument(writer);
                var document = new Document(pdf);

                // Загрузка шрифтов
                var helvetica = PdfFontFactory.CreateFont(iText.IO.Font.PdfFontFactory.HELVETICA, iText.Kernel.Pdf.EncoderConstants.WINANSI, true);
                var boldHelvetica = PdfFontFactory.CreateFont(iText.IO.Font.PdfFontFactory.HELVETICA_BOLD, iText.Kernel.Pdf.EncoderConstants.WINANSI, true);

                // Заголовок
                document.Add(new Paragraph("Отчет о затраченном времени")
                    .SetFont(helvetica)
                    .SetFontSize(12)
                    .SetFontColor(ColorConstants.BLACK));

                document.Add(new Paragraph("\n"));

                // Таблица
                Table table = new Table(data.Columns.Count);
                float[] columnWidths = new float[data.Columns.Count];
                for (int i = 0; i < columnWidths.Length; i++)
                    columnWidths[i] = 1f;
                table.SetWidth(UnitValue.CreatePercentArray(columnWidths).ToArray());

                // Заголовки таблицы
                foreach (DataColumn column in data.Columns)
                {
                    table.AddHeaderCell(new Cell()
                        .Add(new Paragraph(column.ColumnName)
                        .SetFont(boldHelvetica)
                        .SetFontSize(10)
                        .SetFontColor(ColorConstants.WHITE))
                        .SetBackgroundColor(new DeviceRgb(0, 122, 204)));
                }

                // Данные
                foreach (DataRow row in data.Rows)
                {
                    foreach (var item in row.ItemArray)
                    {
                        table.AddCell(new Cell()
                            .Add(new Paragraph(item.ToString())
                            .SetFont(helvetica)
                            .SetFontSize(8)
                            .SetFontColor(ColorConstants.BLACK)));
                    }
                }

                document.Add(table);
                document.Close();
            }
        }
    }
}
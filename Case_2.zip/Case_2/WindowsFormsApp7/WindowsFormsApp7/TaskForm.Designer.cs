﻿using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
    partial class TaskForm
    {
        private DataGridView dgvTasks;
        private Button btnAddTask;
        private Button btnEditTask;
        private Button btnDeleteTask;

        private void InitializeComponent()
        {
            this.dgvTasks = new DataGridView();
            this.btnAddTask = CreateModernButton("Добавить задачу", 620, 30);
            this.btnEditTask = CreateModernButton("Изменить задачу", 620, 80);
            this.btnDeleteTask = CreateModernButton("Удалить задачу", 620, 130);

            // dgvTasks
            this.dgvTasks.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTasks.Location = new Point(12, 12);
            this.dgvTasks.Size = new Size(596, 300);
            this.dgvTasks.BackgroundColor = Color.FromArgb(40, 40, 40);
            this.dgvTasks.GridColor = Color.FromArgb(60, 60, 60);
            this.dgvTasks.RowHeadersVisible = false;

            // Форма
            this.Text = "Задачи — FreelanceHub";
            this.Size = new Size(822, 582);
            this.BackColor = Color.FromArgb(30, 30, 30);
            this.StartPosition = FormStartPosition.CenterScreen;

            // Добавление контролов
            this.Controls.Add(dgvTasks);
            this.Controls.Add(btnAddTask);
            this.Controls.Add(btnEditTask);
            this.Controls.Add(btnDeleteTask);

            // События
            this.btnAddTask.Click += btnAddTask_Click;
            this.btnEditTask.Click += btnEditTask_Click;
            this.btnDeleteTask.Click += btnDeleteTask_Click;
        }

        private Button CreateModernButton(string text, int x, int y)
        {
            return new Button
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(180, 35),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(0, 122, 204),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                FlatAppearance = { MouseOverBackColor = Color.FromArgb(0, 150, 220), BorderSize = 0 }
            };
        }
    }
}
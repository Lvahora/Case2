﻿using System;
using System.Data.SQLite;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
    public partial class TaskForm : Form
    {
        private int _projectId;

        public TaskForm(int projectId)
        {
            _projectId = projectId;
            InitializeComponent();
            LoadTasks();
        }

        private void LoadTasks()
        {
            var tasks = DatabaseManager.GetTasksForProject(_projectId);
            dgvTasks.DataSource = tasks;
        }

        private void btnAddTask_Click(object sender, EventArgs e)
        {
            new AddTaskForm(_projectId).ShowDialog();
            LoadTasks();
        }

        private void btnEditTask_Click(object sender, EventArgs e)
        {
            if (dgvTasks.SelectedRows.Count > 0)
            {
                var selectedRow = dgvTasks.SelectedRows[0];
                int taskId = Convert.ToInt32(selectedRow.Cells["Id"].Value);
                new EditTaskForm(taskId).ShowDialog();
                LoadTasks();
            }
            else
            {
                MessageBox.Show("Выберите задачу для редактирования.");
            }
        }

        private void btnDeleteTask_Click(object sender, EventArgs e)
        {
            if (dgvTasks.SelectedRows.Count > 0)
            {
                var selectedRow = dgvTasks.SelectedRows[0];
                int taskId = Convert.ToInt32(selectedRow.Cells["Id"].Value);

                if (MessageBox.Show("Вы уверены, что хотите удалить эту задачу?", "Подтверждение", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    bool success = DatabaseManager.DeleteTask(taskId);
                    if (success)
                    {
                        MessageBox.Show("Задача успешно удалена.");
                        LoadTasks();
                    }
                    else
                    {
                        MessageBox.Show("Ошибка при удалении задачи.");
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите задачу для удаления.");
            }
        }
    }
}
﻿using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
    partial class TimerForm
    {
        private Label lblTimer;
        private Button btnStart;
        private Button btnStop;

        private void InitializeComponent()
        {
            this.lblTimer = new Label();
            this.btnStart = new Button();
            this.btnStop = new Button();

            // lblTimer
            this.lblTimer.Text = "00:00:00";
            this.lblTimer.Font = new Font("Segoe UI", 24F, FontStyle.Bold);
            this.lblTimer.Location = new Point(150, 50);
            this.lblTimer.Size = new Size(200, 50);
            this.lblTimer.ForeColor = Color.LightGreen;

            // btnStart
            this.btnStart.Text = "Запустить таймер";
            this.btnStart.Location = new Point(100, 120);
            this.btnStart.Size = new Size(150, 40);
            this.btnStart.BackColor = Color.FromArgb(0, 122, 204);
            this.btnStart.ForeColor = Color.White;
            this.btnStart.Click += btnStart_Click;

            // btnStop
            this.btnStop.Text = "Остановить таймер";
            this.btnStop.Location = new Point(260, 120);
            this.btnStop.Size = new Size(150, 40);
            this.btnStop.BackColor = Color.Red;
            this.btnStop.ForeColor = Color.White;
            this.btnStop.Click += btnStop_Click;

            // Форма
            this.Text = "Таймер — FreelanceHub";
            this.Size = new Size(500, 250);
            this.BackColor = Color.FromArgb(30, 30, 30);
            this.StartPosition = FormStartPosition.CenterScreen;

            // Добавление контролов
            this.Controls.Add(lblTimer);
            this.Controls.Add(btnStart);
            this.Controls.Add(btnStop);
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
    public partial class TimerForm : Form
    {
        private int _taskId;
        private DateTime? _startTime;
        private System.Windows.Forms.Timer _timer;
        private TimeSpan _elapsedTime = TimeSpan.Zero;

        public TimerForm(int taskId)
        {
            _taskId = taskId;
            _startTime = null;
            InitializeComponent();
            InitializeTimer();
        }

        private void InitializeTimer()
        {
            _timer = new System.Windows.Forms.Timer();
            _timer.Interval = 1000; // Обновление каждую секунду
            _timer.Tick += Timer_Tick;
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            _elapsedTime = DateTime.Now - _startTime.Value;
            lblTimer.Text = _elapsedTime.ToString(@"hh\:mm\:ss");
        }

        private void StartTimer()
        {
            if (!_startTime.HasValue)
            {
                _startTime = DateTime.Now;
                _timer.Start();
            }
        }

        private void StopTimer()
        {
            if (_startTime.HasValue)
            {
                _timer.Stop();
                SaveTimeEntry();
                _startTime = null;
            }
        }

        private void SaveTimeEntry()
        {
            int durationSeconds = (int)_elapsedTime.TotalSeconds;
            DatabaseManager.AddTimeEntry(_taskId, _startTime.Value, DateTime.Now, durationSeconds);
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            StartTimer();
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            StopTimer();
        }
    }
}
